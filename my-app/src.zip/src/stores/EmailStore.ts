import { makeAutoObservable, action } from "mobx";

class EmailStore {
    email: string = "";
    isEditing: boolean = true;
    showError: boolean = false;

    constructor() {
        makeAutoObservable(this, {
            setEmail: action,
            saveToLocalStorage: action,
            loadFromLocalStorage: action,
            toggleEditing: action
        });
        this.loadFromLocalStorage();
    }

    setEmail(email: string) {
        this.email = email;
        this.showError = false;
    }

    saveToLocalStorage() {
        if (this.isEmailValid) {
            localStorage.setItem("email", this.email);
            this.isEditing = false;
            this.showError = false;
        } else {
            this.showError = true;
        }
    }

    loadFromLocalStorage() {
        const email = localStorage.getItem("email");
        if (email) {
            this.email = email;
            this.isEditing = false;
        }
    }

    toggleEditing() {
        this.isEditing = true;
    }

    get isEmailValid() {
        return /\S+@\S+\.\S+/.test(this.email);
    }
}

const emailStore = new EmailStore();
export default emailStore;
