import React from "react";
import { observer } from "mobx-react";
import EmailDisplay from "./emailForm/EmailDisplay";
import emailStore from "../../stores/EmailStore";
import EmailInputForm from "./emailForm/EmailInputForm";

const EmailForm: React.FC = () => {
  console.log(emailStore.isEditing)
  return (
    <div>
      {emailStore.isEditing ? <EmailInputForm /> : <EmailDisplay />}
    </div>
  );
};

export default observer(EmailForm);
