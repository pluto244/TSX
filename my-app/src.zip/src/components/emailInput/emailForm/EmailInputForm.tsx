import React, { ChangeEvent } from "react";
import { observer } from "mobx-react";
import emailStore from "../../../stores/EmailStore";

const EmailInputForm = () => {
  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    emailStore.setEmail(e.target.value);
  };

  const handleSave = () => {
    emailStore.saveToLocalStorage();
  };
  
  return (
    <div>
      <form>
        <label>
          Email:
          <input type="email" value={emailStore.email} onChange={handleChange} />
        </label>
      </form>
      <button onClick={handleSave} disabled={!emailStore.isEmailValid}>
        Save Email
      </button>
      {emailStore.showError && <p style={{ color: 'red' }}>Invalid email address</p>}
    </div>
  );
};

export default observer(EmailInputForm);
