import React from "react";
import { observer } from "mobx-react";
import emailStore from "../../../stores/EmailStore";

const EmailDisplay: React.FC = () => {

  const handleEdit = () => {
    emailStore.toggleEditing();
  };

  return (
    <div>
      <p>Email: {emailStore.email}</p>
      <button onClick={handleEdit}>Edit Email</button>
    </div>
  );
};

export default observer(EmailDisplay);
