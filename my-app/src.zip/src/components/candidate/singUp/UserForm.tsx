import React, { useEffect } from "react";
import { observer } from "mobx-react";
import userFormStore from "../../../stores/UserFormStore";
import TextInput from "./inputs/TextInput";
import SelectInput from "./inputs/SelectInput";
import rolesStore from "../../../stores/RolesStore";


const UserForm: React.FC = () => {
  useEffect(() => {
    userFormStore.loadEmailFromLocalStorage();
    if (rolesStore.roles.length === 0) {
      rolesStore.loadFromLocalStorage();
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await userFormStore.submitForm();
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <TextInput
          label="Last Name"
          value={userFormStore.lastName}
          onChange={userFormStore.setLastName}
          disabled={userFormStore.isSubmitted}
        />
        <TextInput
          label="First Name"
          value={userFormStore.firstName}
          onChange={userFormStore.setFirstName}
          disabled={userFormStore.isSubmitted}
        />
        <SelectInput
          label="Role"
          value={userFormStore.selectedRole}
          options={rolesStore.roles}
          onChange={userFormStore.setSelectedRole}
          disabled={userFormStore.isSubmitted}
        />

        
        <button type="submit" disabled={userFormStore.isSubmitted}>
          Submit
        </button>
        {userFormStore.error && <p style={{ color: 'red' }}>{userFormStore.error}</p>}
        {userFormStore.responseMessage && <p>{userFormStore.responseMessage}</p>}
      </form>
    </div>
  );
};

export default observer(UserForm);
