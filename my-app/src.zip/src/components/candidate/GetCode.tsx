import React from 'react'

export default function GetCode() {
  return (
    <div>
      
    </div>
  )
}
