import React from "react";
import ApiCaller from "./components/ApiCaller";
import styled from "styled-components";

const App = () => {
    return (
        
        <AppContainer>
            <h1>Email Input Form</h1>
            <ApiCaller />
        </AppContainer>
    );
};


const AppContainer = styled.div`
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    align-content: center;
    flex-wrap: wrap;
    gap: 30px
`



export default App;
